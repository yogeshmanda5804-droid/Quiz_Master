package Main_Menu;

public class Student {
	int id;
	String firstName, lastName, username, password, city, email, mobile;


	public Student(String firstName, String lastName, String username, String password,
	String city, String email, String mobile) {
	this.firstName = firstName;
	this.lastName = lastName;
	this.username = username;
	this.password = password;
	this.city = city;
	this.email = email;
	this.mobile = mobile;
	}

}
